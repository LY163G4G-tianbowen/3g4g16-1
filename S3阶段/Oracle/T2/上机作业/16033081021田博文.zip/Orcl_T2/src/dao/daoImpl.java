package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import odbc.ODBC;

import oracle.jdbc.driver.DBConversion;
import vo.Emp;

public class daoImpl {
	static Connection conn=null;
	static Statement st=null;
	static ResultSet rs=null;
	static PreparedStatement ps=null;
	
	public List<Emp> find(){
		List<Emp> list=new ArrayList<Emp>();
		try {
			conn=ODBC.getConn();
			String sql="select * from emp";
			st=conn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				Emp emp=new Emp();
				emp.setEmpno(rs.getInt("empno"));
				emp.setEname(rs.getString("ename"));
				emp.setJob(rs.getString("job"));
				emp.setSal(rs.getInt("sal"));
				list.add(emp);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	public Emp find(int empno){
		Emp emp=null;
		try {
			conn=ODBC.getConn();
			String sql="select * from emp where empno=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, empno);
			rs=ps.executeQuery();
			
			while(rs.next()){
				emp=new Emp();
				emp.setEmpno(rs.getInt("empno"));
				emp.setEname(rs.getString("ename"));
				emp.setJob(rs.getString("job"));
				emp.setSal(rs.getInt("sal"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return emp;
	}
	public int add(int empno,String ename,String job,int sal){
		int i=0;
		
		try {
			conn=ODBC.getConn();
			String sql="insert into emp(empno,ename,job,sal) values(?,?,?,?)";
			ps=conn.prepareStatement(sql);
			ps.setInt(1,empno);
			ps.setString(2,ename);
			ps.setString(3, job);
			ps.setInt(4, sal);
			ps.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return i;
	}
	public int update(String ename,int empno){
		int i=0;
		try {
			conn=ODBC.getConn();
			String sql="update emp set ename=? where empno=?";
			ps=conn.prepareStatement(sql);
			ps.setString(1,ename);
			ps.setInt(2, empno);
			i=ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return i;
	}
	public int delete(int empno){
		
		int i=0;
		try {
			conn=ODBC.getConn();
			String sql="delete from emp where empno=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1,empno);
			ps.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return i;
		
	}
	
	
}
