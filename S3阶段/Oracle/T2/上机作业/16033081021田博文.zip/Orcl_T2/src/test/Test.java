package test;

import java.util.List;

import vo.Emp;

import dao.daoImpl;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
//		���ϲ�ѯ
		daoImpl dao=new daoImpl();
//		List<Emp> list=dao.find();
//		for (Emp emp : list) {
//			System.out.println(emp.getEmpno()+"---"+emp.getEname());
//		}
		
//		����
//		dao.add(2540,"BluecLe", "teacher", 2500);
		
//		�޸�
//		dao.update("miller", 7934);
		
//		�����ѯ
//		Emp emp=dao.find(2540);
//		System.out.println(emp.getEmpno());
//		System.out.println(emp.getEname());
//		System.out.println(emp.getJob());
//		System.out.println(emp.getSal());
	}

}
